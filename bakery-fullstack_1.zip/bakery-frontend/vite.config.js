import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// เชื่อม Frontend (Vite dev server, port 5173) เข้ากับ Backend API
// (bakery-mrp/src/api/server.js, port 3000) ผ่าน proxy เส้นทาง /api/*
// ทำให้ code ฝั่ง frontend เรียก fetch('/api/forecast') ได้เลยโดยไม่ติด CORS
// แม้ backend จะเปิด CORS ให้แล้วก็ตาม (proxy สะดวกกว่าเวลา deploy จริงหลัง Nginx เดียวกัน)
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
});
