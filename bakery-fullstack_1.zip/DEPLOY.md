# Bakery Purchasing / MRP / BOM — Deploy Guide (GitHub → Firebase Hosting)

เอกสารนี้อธิบายขั้นตอน Deploy **Frontend** (`bakery-frontend/`) ขึ้น Firebase Hosting
โปรเจกต์ `po-innova` แบบอัตโนมัติทุกครั้งที่ Push ขึ้น GitHub

> **สำคัญ:** Firebase Hosting เสิร์ฟได้แค่ไฟล์ Static (HTML/JS/CSS) เท่านั้น —
> **ไม่รองรับ Backend Node.js** (`bakery-mrp/`) ที่ทำไว้ ต้อง Deploy Backend แยกไปที่อื่น
> (ดูหัวข้อ "Deploy Backend" ด้านล่าง) แล้วเอา URL มาใส่ให้ Frontend รู้จัก ไม่งั้นหน้าเว็บ
> จะขึ้นแต่กด Login/โหลดข้อมูลไม่ได้เลย (เพราะยิง API ไปที่ backend ไม่เจอ)

## ขั้นตอนทั้งหมด (ทำที่เครื่องคุณเอง — Sandbox นี้ไม่มีเน็ตให้รันแทนได้)

### 1. สร้าง GitHub Repository

```bash
# แตกไฟล์ zip ที่ได้รับ แล้ว cd เข้าไปที่โฟลเดอร์รวม (มี bakery-mrp/, bakery-frontend/, .github/)
git init
git add .
git commit -m "Initial commit: bakery purchasing/MRP/BOM system"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

### 2. สร้าง Firebase Service Account Secret

```bash
npm install -g firebase-tools
firebase login
cd bakery-frontend
firebase init hosting:github
```

คำสั่งนี้จะถาม GitHub repo ของคุณ แล้ว**สร้าง Secret ชื่อ
`FIREBASE_SERVICE_ACCOUNT_PO_INNOVA` ให้อัตโนมัติ** ใน GitHub repo settings —
ถ้าเลือกให้มันสร้าง Workflow ไฟล์ให้เองด้วย ให้ตอบไม่ (เพราะมีให้แล้วใน
`.github/workflows/`) หรือจะ Merge/เทียบกับของที่ให้มาก็ได้

หากไม่อยากใช้ `firebase init hosting:github` (เผื่อ CLI ถามอะไรที่ไม่แน่ใจ) ทำมือได้:
1. Firebase Console → Project Settings → Service Accounts → Generate New Private Key (ได้ไฟล์ JSON)
2. GitHub repo → Settings → Secrets and variables → Actions → New repository secret
   - ชื่อ: `FIREBASE_SERVICE_ACCOUNT_PO_INNOVA`
   - ค่า: paste เนื้อหาไฟล์ JSON ทั้งไฟล์

### 3. ตั้ง Secret สำหรับ Backend URL (ถ้ายังไม่มี Backend ที่ Deploy แล้ว ข้ามได้ก่อน)

GitHub repo → Settings → Secrets and variables → Actions → New repository secret:
- ชื่อ: `VITE_API_BASE_URL`
- ค่า: URL เต็มของ Backend เช่น `https://bakery-mrp-api.onrender.com`

### 4. Push ขึ้น GitHub

```bash
git add .
git commit -m "chore: trigger deploy"
git push
```

GitHub Actions (`.github/workflows/firebase-hosting-merge.yml`) จะ Build + Deploy
อัตโนมัติ ดูสถานะได้ที่แท็บ **Actions** ของ repo — เสร็จแล้วเปิดดูเว็บได้ที่:

```
https://po-innova.web.app
```

Pull Request ใด ๆ ที่แก้ `bakery-frontend/**` จะได้ Preview URL แยกอัตโนมัติ
(`firebase-hosting-pull-request.yml`) โดยไม่กระทบเว็บจริง

## ⚠️ สิ่งที่ยังต้องทำเอง (ยืนยันไม่ได้จากฝั่งนี้ เพราะ Sandbox ไม่มีเน็ต)

- **ยังไม่เคยรัน `npm install` จริง** ในทั้งสองโปรเจกต์ (ไม่มี `package-lock.json` มาด้วย)
  — รันครั้งแรกที่เครื่องคุณแล้ว commit `package-lock.json` ทั้งคู่เข้า Git ด้วย
  (Workflow ใช้ `npm ci` ซึ่งต้องมีไฟล์นี้)
- **ยังไม่เคย Deploy จริงกับ Firebase Project `po-innova`** — ครั้งแรกอาจเจอ error เล็กน้อย
  เช่น สิทธิ์ Service Account หรือชื่อ Secret ไม่ตรง ถ้าเจอ Actions log แล้วส่งกลับมาได้เลย
- **แนะนำ Backend สำหรับ Deploy จริง** (เลือกอย่างใดอย่างหนึ่ง แล้วดูคู่มือของผู้ให้บริการ):
  - Render.com / Railway.app — ง่ายสุด รองรับ Node ตรง ๆ ไม่ต้องแก้โค้ด
  - Fly.io — ต้องมี Dockerfile (ยังไม่ได้เตรียมไว้ในโปรเจกต์นี้)
  - Google Cloud Run — เข้ากับ Firebase Project เดียวกัน (`po-innova`) ได้ลงตัวที่สุด
    แต่ต้อง containerize (`Dockerfile`) และปรับ `router.js`/`server.js` เล็กน้อยให้ฟัง
    `process.env.PORT` ที่ Cloud Run กำหนด (ปัจจุบันโค้ดรองรับ `process.env.PORT` อยู่แล้ว
    ดู `src/api/server.js`)

## Firebase Config ที่ให้มา

```js
const firebaseConfig = {
  apiKey: "AIzaSyBxEa_yKLTzGz-ICV_bsZDVU1NHx8MiOTg",
  authDomain: "po-innova.firebaseapp.com",
  projectId: "po-innova",
  storageBucket: "po-innova.firebasestorage.app",
  messagingSenderId: "847160966036",
  appId: "1:847160966036:web:1688cf337d184c6c9bed81",
  measurementId: "G-TMKYJCCEYC"
};
```

ยังไม่ได้ฝังเข้าโค้ด Frontend เพราะตอนนี้ใช้ Firebase แค่ **Hosting** เท่านั้น (ไม่ได้ใช้
Firebase Auth/Firestore/Analytics) — Auth ของระบบนี้ยังเป็น JWT ที่ทำเอง (`bakery-mrp/src/auth/`)
ถ้าอยากเปลี่ยนไปใช้ Firebase Authentication แทน หรือใช้ Firestore แทน Backend เดิม บอกได้เลย
เป็นงานแยกที่ต้องปรับโครงสร้างพอสมควร
